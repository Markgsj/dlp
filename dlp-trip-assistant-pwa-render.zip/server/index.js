
import express from 'express';
import fetch from 'node-fetch';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Config
const PORT = process.env.PORT || 8787;

// Disneyland Paris park IDs on Queue-Times
// Disneyland Park Paris: 4
// Walt Disney Studios Paris: 6
const DLP_PARKS = [4, 6];

// Simple helper to fetch JSON with error handling
async function getJSON(url) {
  const res = await fetch(url, { headers: { 'User-Agent': 'dlp-trip-assistant/1.0' } });
  if (!res.ok) throw new Error(`HTTP {res.status} fetching {url}`);
  return await res.json();
}

// Health
app.get('/api/health', (req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() });
});

// Queue-Times proxy endpoints
app.get('/api/parks', async (req, res) => {
  try {
    const parks = await getJSON('https://queue-times.com/parks.json');
    // Filter for Disneyland Paris parks only
    const flat = [];
    for (const group of parks) {
      for (const park of group.parks) {
        if (DLP_PARKS.includes(park.id)) flat.push(park);
      }
    }
    res.json(flat);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/queue-times/:parkId', async (req, res) => {
  const parkId = Number(req.params.parkId);
  if (!DLP_PARKS.includes(parkId)) return res.status(400).json({ error: 'Unsupported park' });
  try {
    const data = await getJSON(`https://queue-times.com/parks/${parkId}/queue_times.json`);
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Weather (OpenWeather One Call 3.0)
// You must set OPENWEATHER_API_KEY in .env
// Coordinates for Disneyland Paris (approx): 48.870, 2.779
app.get('/api/weather', async (req, res) => {
  const lat = req.query.lat || '48.870';
  const lon = req.query.lon || '2.779';
  const apiKey = process.env.OPENWEATHER_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'Missing OPENWEATHER_API_KEY' });
  try {
    const url = `https://api.openweathermap.org/data/3.0/onecall?lat=${lat}&lon=${lon}&exclude=minutely,alerts&appid=${apiKey}&units=metric`;
    const data = await getJSON(url);
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Serve static frontend
app.use('/', express.static('web'));

app.listen(PORT, () => console.log(`DLP Trip Assistant running on http://localhost:${PORT}`));
